# Obtain the summary file from NCBI's ftp site
wget https://ftp.ncbi.nih.gov/genomes/refseq_old/assembly_summary_refseq.txt


# Betacoronavirus England 1
grep 'GCF_002816195.1' assembly_summary_refseq.txt
wget https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/002/816/195/GCF_002816195.1_ASM281619v1/GCF_002816195.1_ASM281619v1_protein.faa.gz
gunzip GCF_002816195.1_ASM281619v1_protein.faa.gz


# Middle East respiratory syndrome-related coronavirus
grep 'GCF_000901155.1' assembly_summary_refseq.txt
wget https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/000/901/155/GCF_000901155.1_ViralProj183710/GCF_000901155.1_ViralProj183710_protein.faa.gz
gunzip GCF_000901155.1_ViralProj183710_protein.faa.gz


# Human immunodeficiency virus 1
grep 'GCF_000864765.1' assembly_summary_refseq.txt
wget https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/000/864/765/GCF_000864765.1_ViralProj15476/GCF_000864765.1_ViralProj15476_protein.faa.gz
gunzip GCF_000864765.1_ViralProj15476_protein.faa.gz


# Zika virus
grep 'GCF_000882815.3' assembly_summary_refseq.txt
wget https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/000/882/815/GCF_000882815.3_ViralProj36615/GCF_000882815.3_ViralProj36615_protein.faa.gz
gunzip GCF_000882815.3_ViralProj36615_protein.faa.gz


# Influenza A virus (A/California/07/2009(H1N1))
grep 'GCF_001343785.1' assembly_summary_refseq.txt
wget https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/001/343/785/GCF_001343785.1_ViralMultiSegProj274766/GCF_001343785.1_ViralMultiSegProj274766_protein.faa.gz
gunzip GCF_001343785.1_ViralMultiSegProj274766_protein.faa.gz


# Influenza B virus (B/Lee/1940)
grep 'GCF_000820495.2' assembly_summary_refseq.txt
wget https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/000/820/495/GCF_000820495.2_ViralMultiSegProj14656/GCF_000820495.2_ViralMultiSegProj14656_protein.faa.gz
gunzip GCF_000820495.2_ViralMultiSegProj14656_protein.faa.gz

# Severe acute respiratory syndrome coronavirus 2
grep 'GCF_009858895.2' assembly_summary_refseq.txt
wget https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/009/858/895/GCF_009858895.2_ASM985889v3/GCF_009858895.2_ASM985889v3_protein.faa.gz
gunzip GCF_009858895.2_ASM985889v3_protein.faa.gz

echo "Simulated Toy References All Downloaded"






# Download a Covid-19 Sequencing Raw Reads
wget https://sra-pub-sars-cov2.s3.amazonaws.com/sra-src/ERR6326571/gQ23IRL96296.fastq.gz.1
mv gQ23IRL96296.fastq.gz.1 gQ23IRL96296.fastq.gz
gunzip gQ23IRL96296.fastq.gz

echo "Simulated Toy Query Downloaded"







